<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Get current authenticated user with subscription details
     */
    public function me(Request $request)
    {
        $user = $request->user()->load('subscriptionPlan');

        return response()->json([
            'id'                  => $user->id,
            'email'               => $user->email,
            'phone'               => $user->phone,
            'subscription_plan_id'=> $user->subscription_plan_id,
            'plan_name'           => $user->subscriptionPlan?->name,
            'max_devices'         => $user->subscriptionPlan?->max_devices,
            'is_active'           => $user->is_active ?? true,
            'email_verified_at'   => $user->email_verified_at,
        ]);
    }
}
